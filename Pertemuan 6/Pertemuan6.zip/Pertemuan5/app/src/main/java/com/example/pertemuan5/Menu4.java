package com.example.pertemuan5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Menu4 extends AppCompatActivity {
    EditText eTxt_Angka;
    Button bBtn_Tampil2;
    TextView Lbl_Hasil2;
    private Object View;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu4);

        eTxt_Angka = findViewById(R.id.Txt_Angka);
        bBtn_Tampil2 = findViewById(R.id.Btn_Tampil2);
        Lbl_Hasil2 = findViewById(R.id.Lbl_Hasil2);



        }


    public void getHasil(View v) {
    String res = eTxt_Angka.getText().toString();
    int x = 1;
    int y = 1;
    int result = Integer.parseInt(res);


    while (y != result) {
        x = x + 1;
        y = x * x;
    }
    Lbl_Hasil2.setText("Nilai Akar Dari " + res + " Adalah :" + x);
}


    }
