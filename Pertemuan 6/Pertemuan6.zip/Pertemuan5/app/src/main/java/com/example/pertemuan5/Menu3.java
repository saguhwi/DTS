package com.example.pertemuan5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Menu3 extends AppCompatActivity {
    EditText eTxt_Nama;
    Button bBtn_Tampil;
    TextView Lbl_Hasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu3);


        eTxt_Nama = findViewById(R.id.Txt_Nama);
        bBtn_Tampil = findViewById(R.id.Btn_Tampil);
        Lbl_Hasil = findViewById(R.id.Lbl_Hasil);


    }
    public void getBtn_Tampil (View v){
        Lbl_Hasil.setText("Nama Anda Adalah : "+eTxt_Nama.getText());
    }
}
